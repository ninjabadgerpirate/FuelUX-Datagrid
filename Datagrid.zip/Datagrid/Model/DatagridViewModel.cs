﻿namespace Datagrid.Model
{
    public class DatagridViewModel
    {
        public string GridID { get; set; }
        public string GridTitle { get; set; }
    }
}